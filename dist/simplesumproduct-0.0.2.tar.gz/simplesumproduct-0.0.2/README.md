This is an stupid package for a tutorial on how to create a Python package.

We are currently working on the package.