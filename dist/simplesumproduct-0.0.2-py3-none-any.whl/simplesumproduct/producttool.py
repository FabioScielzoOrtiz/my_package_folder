def my_product(x,y):
    return x * y

def my_special_product(x,y):
    return (x * y) / 100