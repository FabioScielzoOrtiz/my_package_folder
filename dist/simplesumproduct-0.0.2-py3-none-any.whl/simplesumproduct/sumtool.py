def my_sum(x,y):
    return x + y

def special_sum(x,y):
    return my_sum(x,y) / 10

